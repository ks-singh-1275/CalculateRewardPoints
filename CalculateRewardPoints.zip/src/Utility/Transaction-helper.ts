import { FILTER, SORT_TYPE } from "../Contants/Enums";
import { ITransaction } from "../Interfaces/State/ITransaction";
import { getThreeMonthDate, sortData } from "./Utility";

export const calculateRewards = (price: number) => {
  if (price >= 50 && price < 100) {
    return price - 50;
  } else if (price >= 100) {
    return 2 * (price - 100) + 50;
  }
  return 0;
};
export const getLastThreeMonthsRecords = (
  transactionList: Array<ITransaction>
): ITransaction[] => {
  let filteredList = transactionList.filter(
    (trans) => trans.transactionDate > getThreeMonthDate()
  );
  return sortData("transactionDate", filteredList, SORT_TYPE.DESCENDING);
};
export const getAllRecords = (
  transactionList: Array<ITransaction>
): ITransaction[] => {
  return sortData("transactionDate", transactionList, SORT_TYPE.DESCENDING);
};

export const addTransactionData = (price: number) => {
  const transaction: ITransaction = {
    price: price,
    rewards: calculateRewards(price),
    transactionDate: new Date(),
  };
  return transaction;
};

export const getTotalRewards = (
  transactionList: Array<ITransaction>
): number => {
  return transactionList.length
    ? transactionList.reduce((acc, key) => key.rewards + acc, 0)
    : 0;
};

export const getPerMonthReward = (
  month: number,
  transactionList: Array<ITransaction>
) => {
  const rewards = [];
  for (let i = 0; i < month; i++) {
    let filteredList = transactionList.filter(
      (trans) => trans.transactionDate.getMonth() === new Date().getMonth() - i
    );
    rewards[i] = filteredList.reduce((acc, key) => key.rewards + acc, 0);
  }
  return rewards;
};

export const fetchRecords = (
  filterType: FILTER,
  transactionList: Array<ITransaction>
) => {
  if(transactionList.length)
  {
  switch (filterType) {
    case FILTER.ALL: {
      return getAllRecords(transactionList);
    }
    case FILTER.TOTAL_REWARDS: {
      return getTotalRewards(transactionList);
    }
    case FILTER.THREE_MONTH: {
      return getLastThreeMonthsRecords(transactionList);
    }
    case FILTER.PER_MONTH_REWARD: {
      return getPerMonthReward(1, transactionList);
    }
    default: {
      return transactionList;
    }
  }
}
return transactionList;
};
export const fetchRewards = (
  filterType: FILTER,
  transactionList: Array<ITransaction>
) => {
  if(transactionList.length)
  {
  switch (filterType) {
    case FILTER.TOTAL_REWARDS: {
      return getTotalRewards(transactionList);
    }
    case FILTER.PER_MONTH_REWARD: {
      return getPerMonthReward(1, transactionList);
    }
    default: {
      return 0;
    }
  }
}
return 0;
};