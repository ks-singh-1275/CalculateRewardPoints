export interface ITransactionList {
  transactionList: any;
  totalReward:number;
}