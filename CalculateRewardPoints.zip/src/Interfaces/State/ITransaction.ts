export interface ITransaction {
  price: number;
  rewards: number;
  transactionDate: Date;
}
