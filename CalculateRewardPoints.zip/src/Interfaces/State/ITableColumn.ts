export interface ITableColumn{
    id:string;
    label:string;
}