import { ITableColumn } from "../Interfaces/State/ITableColumn";

export const month = 3;
export const tableColumns: Array<ITableColumn> = [
  {
    id: "price",
    label: "price",
  },
  {
    id: "rewards",
    label: "rewards",
  },
  {
    id: "transactionDate",
    label: "transactionDate",
  },
];
