export enum SORT_TYPE {
  ASCENDING = "asc",
  DESCENDING = "dsc",
}
export enum FILTER{
  ALL=0,
  TOTAL_REWARDS=1,
  PER_MONTH_REWARD=2,
  THREE_MONTH=3,
}