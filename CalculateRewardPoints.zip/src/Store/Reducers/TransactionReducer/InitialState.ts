import { ITransactionList } from "../../../Interfaces/State/ITransactionList";

export const InitialState:  ITransactionList = {
  transactionList: [],
  totalReward:0
};
