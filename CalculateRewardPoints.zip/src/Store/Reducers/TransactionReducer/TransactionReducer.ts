import { InitialState } from "./InitialState";
import {
  ADD_TRANSACTION,
  GET_TOTAL_REWARDS,
  GET_TRANSACTION_DETAIL,
} from "../../ActionTypes/TransactionActionType";
import { ITransactionList } from "../../../Interfaces/State/ITransactionList";
import { FILTER } from "../../../Contants/Enums";
import {
  addTransactionData,
  fetchRecords,
  fetchRewards,
} from "../../../Utility/Transaction-helper";

export const TransactionReducer = (state: any = InitialState, action: any) => {
  const bindTransactionData = (state: ITransactionList, price: number) => {
    return {
      ...state,
      transactionList: [
        ...state.transactionList,
        { ...addTransactionData(price) },
      ],
    };
  };
  const fetchTransactionAsPerFilter = (
    state: ITransactionList,
    filterType: FILTER
  ) => {
    return {
      ...state,
      transactionList: fetchRecords(filterType, state.transactionList),
    };
  };
  const bindTotalRewards = (state: ITransactionList, filterType: FILTER) => {
    return {
      ...state,
      totalReward: fetchRewards(filterType, state.transactionList),
    };
  };
  switch (action.type) {
    case ADD_TRANSACTION: {
      return bindTransactionData(state, action.price);
    }
    case GET_TRANSACTION_DETAIL: {
      return fetchTransactionAsPerFilter(state, action.filterType);
    }
    case GET_TOTAL_REWARDS: {
      return bindTotalRewards(state, action.filterType);
    }
    default: {
      return state;
    }
  }
};
