import { ITransactionList } from "../../Interfaces/State/ITransactionList";

export type IState = {
   transactions:ITransactionList
}