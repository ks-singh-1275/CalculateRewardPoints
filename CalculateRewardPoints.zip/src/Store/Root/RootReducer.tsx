import { combineReducers } from "redux";
import { IState } from "./RootState";
import { TransactionReducer } from "../Reducers/TransactionReducer/TransactionReducer";
export default combineReducers<IState>({
  transactions: TransactionReducer,
});
