import { FILTER } from "../../Contants/Enums";
import { ADD_TRANSACTION, GET_TRANSACTION_DETAIL,GET_TOTAL_REWARDS } from "../ActionTypes/TransactionActionType";

export const addTransaction = (price:number) => ({
  type: ADD_TRANSACTION,
  price,
});
export const getTransactionList = (filterType:FILTER) => ({
  type: GET_TRANSACTION_DETAIL,
  filterType,
});
export const getTotalRewards = (filterType:FILTER) => ({
  type: GET_TOTAL_REWARDS,
  filterType,
});