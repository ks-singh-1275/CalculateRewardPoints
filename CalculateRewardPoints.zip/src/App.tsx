import React from "react";
import Transaction from "./Component/Transaction";


const App = (props) => {
  return <div><Transaction/></div>;
};

export default (App);
