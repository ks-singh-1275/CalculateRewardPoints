import React  from "react";
import TextField from "@material-ui/core/TextField";

const InputType = (props: any) => {
  const { id, ref } = props;
  return <TextField  id={id} ref={ref} focused={true}  {...props} />;
};
export default InputType;
