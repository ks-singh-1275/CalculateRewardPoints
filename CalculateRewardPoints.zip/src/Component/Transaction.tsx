import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import InputType from "./InputType";
import { Button } from "@material-ui/core";
import { TableList } from "./TableList";
import { tableColumns } from "../Contants/constant";
import { IState } from "../Store/Root/RootState";
import {
  addTransaction,
  getTotalRewards,
  getTransactionList,
} from "../Store/Actions/TransactionActions";
import { FILTER } from "../Contants/Enums";
import { connect } from "react-redux";
import { ITransaction } from "../Interfaces/State/ITransaction";
import Filter from "./Filter";

const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: "100%",
    margin: "20px",
    padding: "20px"
  },
  priceSection: {
    display: "flex",
    width: "100%",
    alignItems: "center",
  },
  inputBox: {
    width: "96%",
    borderRadius:"20px",
    marginRight:"10px"
  },
  flex: {
    display: "flex",
    justifyContent: "center",
    marginTop:"10px"
  },
}));
interface IProps {
  transaction: Array<ITransaction>;
  reward: number;
  addTransaction: (price: number) => void;
  getTransactionData: (filterType: FILTER) => void;
  getRewards: (filterType: FILTER) => void;
}
const Transaction = (props: IProps) => {
  const { root, priceSection, inputBox, flex } = useStyles();
  const {
    transaction,
    reward,
    addTransaction,
    getTransactionData,
    getRewards,
  } = props;
  const [price, setPrice] = useState();
  const [isRewardVisible, showRewards] = useState(false);

  const [filter, setFilter] = useState(FILTER.ALL);

  const onPriceChange = (event: any) => {
    setPrice(event.target.value);
  };

  const filterChangeHandler = (filter: FILTER) => {
    setFilter(filter);
  };

  const transactionHandler = () => {
    addTransaction(price);
    const inputElem: any = document.getElementById("addTransaction");
    if (inputElem) {
      inputElem.value = "";
    }
  };

  useEffect(() => {
    if (filter === FILTER.PER_MONTH_REWARD || filter === FILTER.TOTAL_REWARDS) {
      getRewards(filter);
      showRewards(true);
    } else {
      getTransactionData(filter);
      showRewards(false);
    }

    // eslint-disable-next-line
  }, [filter]);

  return (
    <Card className={root}>
      <CardHeader title="Add Transaction and Calculate Rewards" />
      <div className={priceSection}>
        <div className={inputBox}>
          <InputType
            id="addTransaction"
            type="number"
            onChange={onPriceChange}
            className={inputBox}
          />
        </div>
        <div>
          <Button
            variant="contained"
            color="primary"
            onClick={() => transactionHandler()}
          >
            Add
          </Button>
        </div>
      </div>
      <div className={flex}>
        <Filter selectedFilter={filter} onChangeHandler={filterChangeHandler} />
      </div>
      <CardContent>
        {transaction.length && !isRewardVisible ? (
          <TableList columns={tableColumns} transactionList={transaction} />
        ) : (
        isRewardVisible && <h1> Reward Point: {reward}</h1>
        )}
      </CardContent>
    </Card>
  );
};
const mapStateToProps = (state: IState) => ({
  transaction: state.transactions.transactionList,
  reward: state.transactions.totalReward,
});
const mapDispatchToProps = (dispatch: any) => ({
  addTransaction: (price: number) => dispatch(addTransaction(price)),
  getRewards: (filterType: FILTER) => dispatch(getTotalRewards(filterType)),
  getTransactionData: (filterType: FILTER) =>
    dispatch(getTransactionList(filterType)),
});
export default connect(mapStateToProps, mapDispatchToProps)(Transaction);
