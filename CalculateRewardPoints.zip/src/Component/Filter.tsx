import { FILTER } from "../Contants/Enums";
import React from "react";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
interface IProps {
  selectedFilter: FILTER;
  onChangeHandler: (filter: FILTER) => void;
}
const Filter = (props: IProps) => {
  const { onChangeHandler, selectedFilter } = props;
  return (
    <FormControl component="fieldset">
      <RadioGroup row aria-label="filter" name="filter" >
        <FormControlLabel
          value={FILTER.ALL}
          checked={selectedFilter === FILTER.ALL}
          onChange={()=>onChangeHandler(FILTER.ALL)}
          control={<Radio color="primary" />}
          label="All Records"
        />
        <FormControlLabel
          value={FILTER.THREE_MONTH}
          checked={selectedFilter === FILTER.THREE_MONTH}
          control={<Radio color="primary" />}
          onChange={()=>onChangeHandler(FILTER.THREE_MONTH)}
          label="Three Month Records"
        />
        <FormControlLabel
          value={FILTER.PER_MONTH_REWARD}
          checked={selectedFilter === FILTER.PER_MONTH_REWARD}
          onChange={()=>onChangeHandler(FILTER.PER_MONTH_REWARD)}
          control={<Radio color="primary" />}
          label="Per Month Reward"
        />
        <FormControlLabel
          value={FILTER.TOTAL_REWARDS}
          checked={selectedFilter === FILTER.TOTAL_REWARDS}
          control={<Radio color="primary" />}
          onChange={()=>onChangeHandler(FILTER.TOTAL_REWARDS)}
          label="Total Rewards"
        />
      </RadioGroup>
    </FormControl>
  );
};

export default Filter;
